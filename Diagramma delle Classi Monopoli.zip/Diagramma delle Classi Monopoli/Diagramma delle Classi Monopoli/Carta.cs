﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Media;

namespace Diagramma_delle_Classi_Monopoli
{
    public abstract class Carta
    {
        private string _id;
        private string _titolo;
        private string _descrizione;
        private ImageSource _imgSource;
    }
}